/*
This solution page has been cited from the video by Marty Geier
Joshua Murrill
7/15/12
GSP295 week1 lab
*/
#include <iostream>
#include "SquareMatrix.h"
/*
This is the solution to the SquareMatrix header defining the operations needed to perform the basic functions asked.
*/
using namespace std;                                                                 //namespace to easily use cout and cin

SquareMatrix::SquareMatrix()                                                         //a default constructor that will inialize a matrix class object to the max number of rows and columns
{
	int cMatrix[MAX][MAX];                                                           //the creation of the matrix array
}

void SquareMatrix::MakeEmpty(int n)                                                  //a function to make the matrix of a user defined size and all elements within to 0
{
	bounds = n;                                                                      //using the user defined input to resize the matrix to the desired size inputted from the user
	for (int row = 0; row < bounds; row++)                                           //creation of each row
		for (int col = 0; col < bounds; col++)                                       //the creation of each column within the current row
			cMatrix[row][col] = 0;                                                   //making the element of the current position to 0

}

void SquareMatrix::StoreValue(int i, int j, int value)                               //a function to receive data from the user and store a value at a specified location
{
    for (int row = 0; row <= i; row++)                                               //a row incrementor to get to the location specified by the user
		for (int col = 0; col <= j; col++)                                           //a column incrementor to get to the location specified by the user
			cMatrix[i][j] = value;                                                   //store the value at the said location, user defined
}



void SquareMatrix::Add(SquareMatrix n, SquareMatrix &results)                        //a function to take 2 matrices and add them together
{
	for (int row = 0; row < bounds; row++)                                           //a row incrementor to properly add each element
		for (int col = 0; col < bounds; col++)                                       //a column incrementor to properly add each element
			results.cMatrix[row][col] = cMatrix[row][col] + n.cMatrix[row][col];     //adding the element of the same position of 2 matrices and storing that value in the 3rd matrix
}

void SquareMatrix::Subtract(SquareMatrix n, SquareMatrix &results)                  //a function to take 2 matrices and subtract them 
{
	for (int row = 0; row < bounds; row++)                                         //a row incrementor to properly subtract each element
		for (int col = 0; col < bounds; col++)                                     //a column uincrementor to properly subtract each element
			results.cMatrix[row][col] = cMatrix[row][col] - n.cMatrix[row][col];   //subtracting the element of the same position of 2 matrices and storing that value in the 3rd matrix	
}

void SquareMatrix::Print()                                                        //a function to print all 3 matrices
{
	for (int row = 0; row < bounds; row++)                                       //a row incrementor to display each row element properly
		for (int col = 0; col < bounds; col++)                                   //a column incrementor to display each row element properly
			cout << cMatrix[row][col] << " ";                                    //the displaying of the element at the specified location
	cout<<endl;                                                                  //a blank line seperator to show separation between the three printed matrices
}

void SquareMatrix::Copy(SquareMatrix &n)                                        //a function to copy matrix n into matrix c
{
	for (int row = 0; row < bounds; row++)                                      //a row incrementor to properly copy each element to the proper location
		for (int col = 0; col < bounds; col++)                                  //a column incrementor to properly copy each element to the proper location
			cMatrix[row][col] = n.cMatrix[row][col];                           //copying the specified element to the same element location of matrix c
}