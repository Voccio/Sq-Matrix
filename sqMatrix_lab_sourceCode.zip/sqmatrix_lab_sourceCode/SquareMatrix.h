/*
The following header was found from the video instruction by Marty Geier
Joshua Murrill
7/15/12
GSP295 week1 lab
*/
#ifndef SQUAREMATRIX_H                                         //directives to be used for when including this header page into the solution pages
#define SQUAREMATRIX_H
/*
This is the header for square matrix operations to perform
	MakeEmpty
	StoreValue
	Add
	Subtract
	Print
	Copy
*/
const int MAX = 50;                                            //a maximum value for when the matrices are created so they have a defined size before the user defines a matrix size

	class SquareMatrix
	{
	private:
		int bounds;                                            //current bounds of the matrix, will be less than 50
		int cMatrix[MAX][MAX];                                 //an internal class member that the class functions will use when handling the matrix data
	public:
		SquareMatrix();                                        //defualt constructor
		~SquareMatrix(){}                                      //destructor, does nothing
		void MakeEmpty(int n);                                 //sets matrix bounds to n and all elements to 0, n is a user defined value
		void StoreValue(int i, int j, int value);              //receives user defined data to store a value at a said position that was defined by the user
		void Add(SquareMatrix n, SquareMatrix &results);       //takes matrix a and b and adds them together storing the value in matrix c
		void Subtract(SquareMatrix n, SquareMatrix &results);  //takes matrix a and b and subtracts them storing the results in matrix c, this function will also take order into consideration 
		void Print();                                          //displays all 3 matrices on the screen for the user to see
		void Copy(SquareMatrix &n);                            //copies matrix n into matrix c
	};
#endif                                                         //end the definition of the class header