/*
The skeleton of this code is cited from the lecture video of Marty Geier
Joshua Murrill
7/15/12
GSP295 week1 lab
*/

#include <iostream>
#include "SquareMatrix.h"
#include <conio.h>
#include <cstdlib>
#include  <time.h>
using namespace std;
/*
This is the test drive to execute each of the functions of SquareMatrix. No execptions or error checking is done within this program, so it is asked to stay within the proper operations performed.
*/
int main ()                                                                          //the start of our program to run and test the SquareMatrix class
{
	int num, row, col, val;  
	/*
	num - user defined value for size of matrices
	row - user defined value to position stored data to a specific element within the matrix
	col - user defined value to position stored data to a specific element within the matrix
	val - user defined value for the stored data to a specific element within the matrix
	 */
	char menu;                                                                       // input for menu option 
	SquareMatrix a, b, c;                                                            // creates 3 squareMatrix class objects

	do{                                                                              //a loop to continue the process of menu options so a matrix may be fully manipulated, tested, and retested
		cout << "What would you like to do?" << endl;                                //prompt user that they will make a choice
		cout << "a. Make Empty(resize) matrix" << endl;                              //choose to size 3 square matrices to user defined size and all elements to 0
		cout << "b. Store value in matrix" << endl;                                  //choose a position within the matrix and store a value there
		cout << "c. Add matricies" << endl;                                          //add matrix a and b together storeing the results in c
		cout << "d. Subtract matricies" << endl;                                     //subtract matrix a and b or b and a and store the results in c
		cout << "e. Print matrix" << endl;                                           //display all three matrices on the screen
		cout << "f. Copy matrix" << endl;                                            //copy matrix a to c or copy matric b to c
		cout << "g. Quit." << endl;                                                  //end program
		cin >> menu;                                                                 //user defined choice of the menu options      

		switch (menu)                                                                //pathing based from user defined input
		{             
		case 'a':                                                                    //first path matching the menu choices
			cout << "Enter a value for the size of the square matrix. " << endl;     //prompt user to enter a value 
			cin >> num;                                                              //accept input from user as data
			a.MakeEmpty(num);                                                        //intialize matrix a to user defined size
			b.MakeEmpty(num);                                                        //intialize matrix b to user defined size
			c.MakeEmpty(num);                                                        //intialize matrix c to user defined size
			break;                                                                   //end path
		case 'b':                                                                    //second path matching menu
			cout << "Choose matrix 1 or 2. " << endl;                                //prompt user for input
			cin >> num;                                                              //accept the input
			cout << "Enter a row position. " << endl;                                //prompt user for value
			cin >> row;                                                              //accept value
			cout << "Enter a column position. " << endl;                             //prompt user for value
			cin >> col;                                                              //accept value
			cout << "Enter a value to store at said position. " << endl;             //prompt user for value
			cin >> val;                                                              //accept value
			if(num == 1)                                                             //allow user easy access to choose and change 1 of 2 matrices
				a.StoreValue(row, col, val);                                         //store value at poistion in matrix a that has been all user defined
			else                                                                     //if user didn't define matrix a, then they change matrix b by default currently
				b.StoreValue(row, col, val);                                         //store value at poistion in matrix b that has been all user defined
			break;                                                                   //end path
		case 'c':                                                                   //third path matching menu options
			a.Add(b, c);                                                            //add matrix a and b together
			break;                                                                  //end path
		case 'd':                                                                   //forth path matching the menu options
			cout << "Choose matrix 1 or 2. " << endl;                               //prompt user for input
			cin >> num;                                                             //accept input
			if (num == 1)                                                           //allow user easy access to choose and change 1 of 2 matrices
				b.Subtract(a, c);                                                   //subtract matrix b from a and store into matrix c
			else                                                                    //if user didn't define matrix a, then they change matrix b by default currently
				a.Subtract(b, c);                                                   //subtract matrix a from b and store into matrix c
			break;                                                                  //end path
		case 'e':                                                                   //fifth path matching menu options
			a.Print();                                                              //display matrix a
			cout <<endl;                                                            //empty line for spacing
			b.Print();                                                             //display matrix b
			cout <<endl;                                                           //empty line for spacing
			c.Print();                                                             //display matrix c
			cout <<endl;                                                           //empty line for spacing
			break;                                                                 //end path
		case 'f':                                                                  //sixth path matching menu options
			cout << "Choose matrix 1 or 2. " << endl;                              //prompt user for data
			cin >> num;                                                            //accept data
			if (num == 1)                                                          //allow user easy access to choose and change 1 of 2 matrices
				c.Copy(a);                                                         //copy matrix a into matrix c
			else                                                                   //if user didn't define matrix a, then they change matrix b by default currently
				c.Copy(b);                                                         //copy matrix b into matrix c
			break;                                                                //end path 
		default:                                                                  //path of default
			continue;                                                             // repeat menu if input is not valid menu option
		
	}
	}
	while (menu != 'g' );                                                         //loop to continue menu choices to appear
	cout << "Please press any key to exit ..." << endl;                           //prompt user to confirm program termination
	cin.sync();                                                                   //termination process
	_getch(); 
	return 0;
	
}